//
//  AssetsViewController.swift
//  Uikit-storyboard-tutorial-project
//
//  Created by 박범수 on 6/24/24.
//

import Foundation
import UIKit

class AssetsViewController: UIViewController {

    @IBOutlet var StartView: CustomView!
    override func viewDidLoad() {
        super.viewDidLoad()
        

    }

}

