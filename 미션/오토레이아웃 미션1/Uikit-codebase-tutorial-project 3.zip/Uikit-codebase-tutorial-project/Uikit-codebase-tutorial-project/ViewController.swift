//
//  ViewController.swift
//  Uikit-codebase-tutorial-project
//
//  Created by 박범수 on 6/29/24.
//

import UIKit

class ViewController: UIViewController {

    let checkView = UIImageView()
    let assetLabel = UILabel()
    let completeLabel = UILabel()
    let announcementLabel = UILabel()
    let barView = UIView()
    let cardView = UIView()
    let shinhanView = UIImageView()
    let okView = UIView()
    let okLabel = UILabel()
    let shinhanLabel = UILabel()
    let twoLabel = UILabel()
    let checkboxView = UIView()
    let checkLabel = UILabel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // 배경색 변경
        view.backgroundColor = UIColor.white
        setupUIElements()
        setupConstraints()
    }
    
}

//MARK: - UI세팅
extension ViewController {
    
    /// UI 셋업
    func setupUIElements() {
        // Check 이미지 설정
        if let checkImage = UIImage(named: "Check") {
            checkView.image = checkImage
        } else {
            print("Error: 'Check' 이미지 로드 실패")
        }
        checkView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(checkView)
        
        // "1개 자산" 라벨 설정
        assetLabel.text = "1개 자산"
        assetLabel.textColor = .systemBlue
        assetLabel.font = UIFont.systemFont(ofSize: 20, weight: .medium)
        assetLabel.textAlignment = .center
        assetLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(assetLabel)
        
        // "등록 완료" 라벨 설정
        completeLabel.text = "등록 완료"
        completeLabel.font = UIFont.systemFont(ofSize: 30, weight: .semibold)
        completeLabel.textAlignment = .center
        completeLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(completeLabel)
        
        // 안내 메시지 라벨 설정
        announcementLabel.text = "해당 금융사에서 자산 등록 완료 관련 안내 메시지를\n받게 될 수도 있어요."
        announcementLabel.textColor = .systemGray
        announcementLabel.font = UIFont.systemFont(ofSize: 17, weight: .light)
        announcementLabel.numberOfLines = 2
        announcementLabel.textAlignment = .center
        announcementLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(announcementLabel)
        
        // 회색 bar 설정
        barView.backgroundColor = UIColor.systemGray6
        barView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(barView)
        
        // 카드 뷰 설정
        cardView.backgroundColor = UIColor.systemBackground
        cardView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(cardView)
        
        // 카드 이미지 설정
        if let shinhanImage = UIImage(named: "shinhan") {
            shinhanView.image = shinhanImage
        } else {
            print("Error: 'shinhan' 이미지 로드 실패")
        }
        shinhanView.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(shinhanView)
        
        // 확인 뷰 설정
        okView.backgroundColor = UIColor.systemBlue
        okView.layer.cornerRadius = 10
        okView.layer.masksToBounds = true
        okView.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(okView)
        
        // "확인" 라벨 설정
        okLabel.text = "확인"
        okLabel.textColor = .white
        okLabel.font = UIFont.systemFont(ofSize: 12, weight: .semibold)
        okLabel.translatesAutoresizingMaskIntoConstraints = false
        okView.addSubview(okLabel)
        
        // "신한카드" 라벨 설정
        shinhanLabel.text = "신한카드"
        shinhanLabel.font = UIFont.systemFont(ofSize: 15, weight: .medium)
        shinhanLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(shinhanLabel)
        
        // "2개" 라벨 설정
        twoLabel.text = "2개"
        twoLabel.textColor = .systemGray3
        twoLabel.font = UIFont.systemFont(ofSize: 12)
        twoLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(twoLabel)
        
        // 하단 확인 박스 설정
        checkboxView.backgroundColor = UIColor.systemBlue
        checkboxView.layer.cornerRadius = 10
        checkboxView.layer.masksToBounds = true
        checkboxView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(checkboxView)
        
        // 하단 박스 "확인" 라벨 설정
        checkLabel.text = "확인"
        checkLabel.textColor = .white
        checkLabel.font = UIFont.systemFont(ofSize: 20, weight: .semibold)
        checkLabel.textAlignment = .center
        checkLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(checkLabel)
    }
    
    /// 위치, 크기 셋업
    func setupConstraints() {
        // Check 이미지 위치 크기 설정
        NSLayoutConstraint.activate([
            checkView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor,constant:  100),
            checkView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            checkView.widthAnchor.constraint(equalToConstant: 80),
            checkView.heightAnchor.constraint(equalToConstant: 80)
        ])
        
        // "1개 자산" 라벨 위치 크기 설정
        NSLayoutConstraint.activate([
            assetLabel.topAnchor.constraint(equalTo: checkView.bottomAnchor, constant: 20),
            assetLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            assetLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 0)
        ])
            
        // "등록 완료" 라벨 위치 크기 설정
        NSLayoutConstraint.activate([
            completeLabel.topAnchor.constraint(equalTo: assetLabel.bottomAnchor, constant: 5),
            completeLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            completeLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 0)
        ])
            
        // 안내 메시지 위치 크기 설정
        NSLayoutConstraint.activate([
            announcementLabel.topAnchor.constraint(equalTo: completeLabel.bottomAnchor, constant: 15),
            announcementLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            announcementLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 0),
            announcementLabel.heightAnchor.constraint(equalToConstant: 50)
        ])
            
        // 회색 bar 위치 크기 설정
        NSLayoutConstraint.activate([
            barView.topAnchor.constraint(equalTo: announcementLabel.bottomAnchor, constant: 40),
            barView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            barView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            barView.heightAnchor.constraint(equalToConstant: 1)
        ])
            
        // 카드 뷰 위치 크기 설정
        NSLayoutConstraint.activate([
            cardView.topAnchor.constraint(equalTo: barView.bottomAnchor, constant: 20),
            cardView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            cardView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            cardView.heightAnchor.constraint(equalToConstant: 60)
        ])
            
        // 카드 이미지 위치 크기 설정
        NSLayoutConstraint.activate([
            shinhanView.centerYAnchor.constraint(equalTo: cardView.centerYAnchor),
            shinhanView.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 0),
            shinhanView.widthAnchor.constraint(equalToConstant: 40),
            shinhanView.heightAnchor.constraint(equalToConstant: 50)
        ])
            
        // 확인 뷰 위치 크기 설정
        NSLayoutConstraint.activate([
            okView.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: 0),
            okView.centerYAnchor.constraint(equalTo: cardView.centerYAnchor),
            okView.widthAnchor.constraint(equalToConstant: 35),
            okView.heightAnchor.constraint(equalToConstant: 25)
        ])
            
        // "확인" 라벨 위치 크기 설정
        NSLayoutConstraint.activate([
            okLabel.centerXAnchor.constraint(equalTo: okView.centerXAnchor),
            okLabel.centerYAnchor.constraint(equalTo: okView.centerYAnchor),
        ])
            
        // "신한카드" 라벨 위치 크기 설정
        NSLayoutConstraint.activate([
            shinhanLabel.leadingAnchor.constraint(equalTo: shinhanView.trailingAnchor, constant: 20),
            shinhanLabel.topAnchor.constraint(equalTo: cardView.topAnchor, constant: 8),
            shinhanLabel.trailingAnchor.constraint(equalTo: okView.leadingAnchor, constant: 0)
        ])
            
        // "2개" 라벨 위치 크기 설정
        NSLayoutConstraint.activate([
            twoLabel.leadingAnchor.constraint(equalTo: shinhanView.trailingAnchor, constant: 20),
            twoLabel.topAnchor.constraint(equalTo: shinhanLabel.bottomAnchor, constant: 6),
            twoLabel.trailingAnchor.constraint(equalTo: okView.leadingAnchor, constant: 0)
        ])
        
        // 하단 확인 박스 위치 크기 설정
        NSLayoutConstraint.activate([
            checkboxView.heightAnchor.constraint(equalToConstant: 60),
            checkboxView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            checkboxView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 16),
            checkboxView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -6)
        ])
            
        // 하단 박스 "확인" 라벨 위치 크기 설정
        NSLayoutConstraint.activate([
            checkLabel.centerXAnchor.constraint(equalTo: checkboxView.centerXAnchor),
            checkLabel.centerYAnchor.constraint(equalTo: checkboxView.centerYAnchor),
            checkLabel.leadingAnchor.constraint(equalTo: checkView.leadingAnchor, constant: 0)
        ])
    }
}


#if DEBUG

import SwiftUI

struct ViewControllerPresentable: UIViewControllerRepresentable {
    func updateUIViewController(_ uiViewController: UIViewControllerType, context: Context) {
    }
    
    func makeUIViewController(context: Context) -> some UIViewController {
        ViewController()
    }
}

struct ViewControllerPresentable_PreviewProvider : PreviewProvider {
    static var previews: some View {
        ViewControllerPresentable()
            .ignoresSafeArea()
    }
}

#endif
