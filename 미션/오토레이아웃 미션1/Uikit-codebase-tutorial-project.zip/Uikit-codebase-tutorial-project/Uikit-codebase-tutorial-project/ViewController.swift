//
//  ViewController.swift
//  Uikit-codebase-tutorial-project
//
//  Created by 박범수 on 6/29/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        // 배경색 변경
        view.backgroundColor = UIColor.white
        
        // Check 이미지 추가
        guard let checkImage = UIImage(named: "Check") else {
            print("Error: 'Check' 이미지 로드 실패")
            return
        }
        let checkView = UIImageView(image: checkImage)
        checkView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(checkView)
                
        // Check 이미지 위치 크기 설정
        NSLayoutConstraint.activate([
            checkView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 100),
            checkView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            checkView.widthAnchor.constraint(equalToConstant: 80),
            checkView.heightAnchor.constraint(equalToConstant: 80)
        ])
            
        // "1개 자산" 추가
        let assetLabel = UILabel()
        assetLabel.text = "1개 자산"
        assetLabel.textColor = .systemBlue
        assetLabel.font = UIFont.systemFont(ofSize: 20, weight: .medium)
        assetLabel.textAlignment = .center
        assetLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(assetLabel)
        
        // "1개 자산" 위치 크기
        NSLayoutConstraint.activate([
            assetLabel.topAnchor.constraint(equalTo: checkView.bottomAnchor, constant: 20),
            assetLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            assetLabel.widthAnchor.constraint(equalToConstant: 70)
        ])
            
        // "등록 완료" 추가
        let completeLabel = UILabel()
        completeLabel.text = "등록 완료"
        completeLabel.font = UIFont.systemFont(ofSize: 30, weight: .semibold)
        completeLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(completeLabel)
        
        // "등록 완료" 위치 크기
        NSLayoutConstraint.activate([
            completeLabel.topAnchor.constraint(equalTo: assetLabel.bottomAnchor, constant: 5),
            completeLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            completeLabel.widthAnchor.constraint(equalToConstant: 120)
        ])
            
        // 안내 메시지 추가
        let announcementLabel = UILabel()
        announcementLabel.text = "해당 금융사에서 자산 등록 완료 관련 안내 메시지를\n받게 될 수도 있어요."
        announcementLabel.textColor = .systemGray
        announcementLabel.font = UIFont.systemFont(ofSize: 17, weight: .light)
        announcementLabel.numberOfLines = 2
        announcementLabel.textAlignment = .center
        announcementLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(announcementLabel)
        
        // 안내 메시지 위치 크기
        NSLayoutConstraint.activate([
            announcementLabel.topAnchor.constraint(equalTo: completeLabel.bottomAnchor, constant: 15),
            announcementLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            announcementLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 0),
            announcementLabel.heightAnchor.constraint(equalToConstant: 50)
        ])
            
        // 회색 bar 추가
        let barView = UIView()
        barView.backgroundColor = UIColor.systemGray6
        barView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(barView)
        
        // 회색 bar 위치 크기
        NSLayoutConstraint.activate([
            barView.topAnchor.constraint(equalTo: announcementLabel.bottomAnchor, constant: 40),
            barView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            barView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            barView.heightAnchor.constraint(equalToConstant: 1)
        ])
            
        // 카드 뷰
        let cardView = UIView()
        cardView.backgroundColor = UIColor.systemBackground
        cardView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(cardView)
        
        // 카드 뷰 위치 크기
        NSLayoutConstraint.activate([
            cardView.topAnchor.constraint(equalTo: barView.topAnchor, constant: 20),
            cardView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            cardView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            cardView.heightAnchor.constraint(equalToConstant: 60)
        ])
        
        // 카드 이미지
        guard let shinhanImage = UIImage(named: "shinhan") else {
            print("Error: 'shinhan' 이미지 로드 실패")
            return
        }
        let shinhanView = UIImageView(image: shinhanImage)
        shinhanView.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(shinhanView)
        
        // 카드 이미지 위치 크기
        NSLayoutConstraint.activate([
            shinhanView.centerYAnchor.constraint(equalTo: cardView.centerYAnchor),
            shinhanView.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 0),
            shinhanView.widthAnchor.constraint(equalToConstant: 40),
            shinhanView.heightAnchor.constraint(equalToConstant: 50)
        ])
        
        // "신한카드" 추가
        let shinhanLabel = UILabel()
        shinhanLabel.text = "신한카드"
        shinhanLabel.font = UIFont.systemFont(ofSize: 15, weight: .medium)
        shinhanLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(shinhanLabel)
        
        NSLayoutConstraint.activate([
            shinhanLabel.leadingAnchor.constraint(equalTo: shinhanView.trailingAnchor, constant: 20),
            shinhanLabel.topAnchor.constraint(equalTo: cardView.topAnchor, constant: 8),
            shinhanLabel.widthAnchor.constraint(equalToConstant: 52)
        ])
        
        // "2개" 추가
        let twoLabel = UILabel()
        twoLabel.text = "2개"
        twoLabel.textColor = .systemGray3
        twoLabel.font = UIFont.systemFont(ofSize: 12)
        twoLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(twoLabel)
        
        NSLayoutConstraint.activate([
            twoLabel.leadingAnchor.constraint(equalTo: shinhanView.trailingAnchor, constant: 20),
            twoLabel.topAnchor.constraint(equalTo: shinhanLabel.bottomAnchor, constant: 6),
            twoLabel.widthAnchor.constraint(equalToConstant: 18)
        ])
        
        // 확인 뷰
        let okView = UIView()
        okView.backgroundColor = UIColor.systemBlue
        okView.layer.cornerRadius = 10
        okView.layer.masksToBounds = true
        okView.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(okView)
        
        NSLayoutConstraint.activate([
            okView.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: 0),
            okView.centerYAnchor.constraint(equalTo: cardView.centerYAnchor),
            okView.widthAnchor.constraint(equalToConstant: 35),
            okView.heightAnchor.constraint(equalToConstant: 25)
        ])
        
        // "확인"
        let okLabel = UILabel()
        okLabel.text = "확인"
        okLabel.textColor = .white
        okLabel.font = UIFont.systemFont(ofSize: 12, weight: .semibold)
        okLabel.translatesAutoresizingMaskIntoConstraints = false
        okView.addSubview(okLabel)
        
        NSLayoutConstraint.activate([
            okLabel.centerXAnchor.constraint(equalTo: okView.centerXAnchor),
            okLabel.centerYAnchor.constraint(equalTo: okView.centerYAnchor),
        ])
        
        // 하단 확인 박스
        let checkboxView = UIView()
        checkboxView.backgroundColor = UIColor.systemBlue
        checkboxView.layer.cornerRadius = 10
        checkboxView.layer.masksToBounds = true
        checkboxView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(checkboxView)
        
        NSLayoutConstraint.activate([
            checkboxView.heightAnchor.constraint(equalToConstant: 60),
            checkboxView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            checkboxView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 16),
            checkboxView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: 6)
        ])
        
        // 하단 박스 "확인"
        let checkLabel = UILabel()
        checkLabel.text = "확인"
        checkLabel.textColor = .white
        checkLabel.font = UIFont.systemFont(ofSize: 20, weight: .semibold)
        checkLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(checkLabel)
        
        NSLayoutConstraint.activate([
            checkLabel.centerXAnchor.constraint(equalTo: checkboxView.centerXAnchor),
            checkLabel.centerYAnchor.constraint(equalTo: checkboxView.centerYAnchor),
        ])
        
    }
    
}

#if DEBUG

import SwiftUI

struct ViewControllerPresentable: UIViewControllerRepresentable {
    func updateUIViewController(_ uiViewController: UIViewControllerType, context: Context) {
    }
    
    func makeUIViewController(context: Context) -> some UIViewController {
        ViewController()
    }
}

struct ViewControllerPresentable_PreviewProvider : PreviewProvider {
    static var previews: some View {
        ViewControllerPresentable()
            .ignoresSafeArea()
    }
}

#endif
