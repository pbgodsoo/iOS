//
//  SecondViewController.swift
//  Uikit-codebase-tutorial-project
//
//  Created by 박범수 on 6/30/24.
//

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .white
        
        // 네비게이션 바
        let navigationBar = UINavigationBar()
        navigationBar.translatesAutoresizingMaskIntoConstraints = false
        navigationBar.barTintColor = .white // 네비게이션 바 틴트 색상 설정
        view.addSubview(navigationBar)
        
        // 네비게이션 shadow 투명
        let shadowImage = UIImage(named: "1x1empty")
        navigationBar.shadowImage = shadowImage
        
        // 네비게이션 바 요소 추가
        let navigationItem = UINavigationItem(title: "자산추가")
        let leftButton = UIBarButtonItem(image: UIImage(systemName: "chevron.backward"))
        leftButton.tintColor = .black
        navigationItem.leftBarButtonItem = leftButton
        navigationBar.setItems([navigationItem], animated: false)
        
        // 네비게이션 바 위치 크기
        NSLayoutConstraint.activate([
            navigationBar.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            navigationBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            navigationBar.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])
        
        // 메시지
        let messageLabel = UILabel()
        messageLabel.text = "내 계과, 카드를 한번에 모아\n모니모에서 관리해보세요"
        messageLabel.font = UIFont.systemFont(ofSize: 30, weight: .medium)
        messageLabel.numberOfLines = 2
        messageLabel.textAlignment = .center
        messageLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(messageLabel)
        
        // 메시지 위치 크기
        NSLayoutConstraint.activate([
            messageLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            messageLabel.topAnchor.constraint(equalTo: navigationBar.bottomAnchor, constant: 69),
            messageLabel.leadingAnchor.constraint(equalToSystemSpacingAfter: view.safeAreaLayoutGuide.leadingAnchor, multiplier: 0),
            messageLabel.heightAnchor.constraint(equalToConstant: 80)
        ])
        
        // asset 이미지 추가
        guard let assetImage = UIImage(named: "AssetImage") else {
            print("Error: 'AssetImage' 이미지 로드 실패")
            return
        }
        let assetView = UIImageView(image: assetImage)
        assetView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(assetView)

        // asset 이미지 위치 크기
        NSLayoutConstraint.activate([
            assetView.topAnchor.constraint(equalTo: messageLabel.bottomAnchor, constant: 96),
            assetView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            assetView.widthAnchor.constraint(equalToConstant: 170),
            assetView.heightAnchor.constraint(equalToConstant: 170)
        ])
        
        // 메시지2
        let secondmessageLabel = UILabel()
        secondmessageLabel.text = "1분 만에,\n계좌와 카드를 찾아 드려요"
        secondmessageLabel.font = UIFont.systemFont(ofSize: 20)
        secondmessageLabel.textColor = .systemBlue
        secondmessageLabel.numberOfLines = 2
        secondmessageLabel.textAlignment = .center
        secondmessageLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(secondmessageLabel)
        
        // 메시지2 위치 크기
        NSLayoutConstraint.activate([
            secondmessageLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            secondmessageLabel.topAnchor.constraint(equalTo: assetView.bottomAnchor, constant: 116),
            secondmessageLabel.leadingAnchor.constraint(equalToSystemSpacingAfter: view.safeAreaLayoutGuide.leadingAnchor, multiplier: 0),
            secondmessageLabel.heightAnchor.constraint(equalToConstant: 50)
        ])
        
        // 하단 확인 박스
        let checkboxView = UIView()
        checkboxView.backgroundColor = UIColor.systemBlue
        checkboxView.layer.cornerRadius = 10
        checkboxView.layer.masksToBounds = true
        checkboxView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(checkboxView)
        
        NSLayoutConstraint.activate([
            checkboxView.heightAnchor.constraint(equalToConstant: 60),
            checkboxView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            checkboxView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 16),
            checkboxView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: 6)
        ])
        
        // 하단 박스 "확인"
        let checkLabel = UILabel()
        checkLabel.text = "확인"
        checkLabel.textColor = .white
        checkLabel.font = UIFont.systemFont(ofSize: 20, weight: .semibold)
        checkLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(checkLabel)
        
        NSLayoutConstraint.activate([
            checkLabel.centerXAnchor.constraint(equalTo: checkboxView.centerXAnchor),
            checkLabel.centerYAnchor.constraint(equalTo: checkboxView.centerYAnchor),
        ])
    }
}

#if DEBUG

import SwiftUI

struct SecondViewControllerPresentable: UIViewControllerRepresentable {
    func updateUIViewController(_ uiViewController: UIViewControllerType, context: Context) {
    }
    
    func makeUIViewController(context: Context) -> some UIViewController {
        SecondViewController()
    }
}

struct SecondViewControllerPresentable_PreviewProvider: PreviewProvider {
    static var previews: some View {
        SecondViewControllerPresentable()
            .ignoresSafeArea()
    }
}

#endif
