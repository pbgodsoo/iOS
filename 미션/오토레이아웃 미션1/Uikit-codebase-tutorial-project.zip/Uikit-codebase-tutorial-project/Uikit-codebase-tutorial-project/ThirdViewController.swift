//
//  ThirdViewController.swift
//  Uikit-codebase-tutorial-project
//
//  Created by 박범수 on 7/1/24.
//

import UIKit

class ThirdViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 배경색 변경
        view.backgroundColor = UIColor.systemGray5
        
        // 하얀색 뷰
        let whiteView = UIView()
        whiteView.backgroundColor = .white
        whiteView.layer.cornerRadius = 30
        whiteView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(whiteView)
        
        // 하얀색 뷰 위치 크기
        NSLayoutConstraint.activate([
            whiteView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            whiteView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            whiteView.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 1),
            whiteView.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.6)
        ])
        
        // 자물쇠 이미지
        guard let lockImage = UIImage(named: "lock") else {
            print("Error: 'lockImage' 이미지 로드 실패")
            return
        }
        let lockView = UIImageView(image: lockImage)
        lockView.translatesAutoresizingMaskIntoConstraints = false
        whiteView.addSubview(lockView)
        
        // 자물쇠 이미지 위치 크기
        NSLayoutConstraint.activate([
            lockView.topAnchor.constraint(equalTo: whiteView.topAnchor, constant: 60),
            lockView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            lockView.widthAnchor.constraint(equalToConstant: 100),
            lockView.heightAnchor.constraint(equalToConstant: 100)
        ])
        
        // "다음부터" 메시지
        let nextLabel = UILabel()
        nextLabel.text = "다음부터\n자동으로 로그인할까요?"
        nextLabel.font = UIFont.systemFont(ofSize: 20, weight: .medium)
        nextLabel.numberOfLines = 2
        nextLabel.textAlignment = .center
        nextLabel.translatesAutoresizingMaskIntoConstraints = false
        whiteView.addSubview(nextLabel)
        
        // 메시지 위치 크기
        NSLayoutConstraint.activate([
            nextLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            nextLabel.topAnchor.constraint(equalTo: lockView.bottomAnchor, constant: 30),
            nextLabel.leadingAnchor.constraint(equalToSystemSpacingAfter: view.safeAreaLayoutGuide.leadingAnchor, multiplier: 0)
        ])
        
        // "설정" 메시지
        let settingLabel = UILabel()
        settingLabel.text = "'설정'에서 언제든 변경할 수 있어요."
        settingLabel.textColor = .systemGray
        settingLabel.font = UIFont.systemFont(ofSize: 17)
        settingLabel.numberOfLines = 1
        settingLabel.textAlignment = .center
        settingLabel.translatesAutoresizingMaskIntoConstraints = false
        whiteView.addSubview(settingLabel)
        
        // 메시지 위치 크기
        NSLayoutConstraint.activate([
            settingLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            settingLabel.topAnchor.constraint(equalTo: nextLabel.bottomAnchor, constant: 15),
            settingLabel.widthAnchor.constraint(equalToConstant: 240)
        ])
        
        // 다음에 할게요 박스
        let nextboxView = UIView()
        nextboxView.backgroundColor = UIColor.systemGray6
        nextboxView.layer.cornerRadius = 10
        nextboxView.layer.masksToBounds = true
        nextboxView.translatesAutoresizingMaskIntoConstraints = false
        whiteView.addSubview(nextboxView)
        
        // 다음에 할게요 박스 위치 크기
        NSLayoutConstraint.activate([
            nextboxView.heightAnchor.constraint(equalToConstant: 55),
            nextboxView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            nextboxView.leadingAnchor.constraint(equalTo: whiteView.leadingAnchor, constant: 24),
            nextboxView.bottomAnchor.constraint(equalTo: whiteView.bottomAnchor, constant: -40)
        ])
        
        // "다음에 할게요" 라벨
        let nextdoLabel = UILabel()
        nextdoLabel.text = "다음에 할게요"
        nextdoLabel.textColor = .systemBlue
        nextdoLabel.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        nextdoLabel.translatesAutoresizingMaskIntoConstraints = false
        nextboxView.addSubview(nextdoLabel)
        
        // "다음에 할게요" 라벨 위치 크기
        NSLayoutConstraint.activate([
            nextdoLabel.centerXAnchor.constraint(equalTo: nextboxView.centerXAnchor),
            nextdoLabel.centerYAnchor.constraint(equalTo: nextboxView.centerYAnchor),
        ])
        
        // 네, 좋아요 박스
        let yesboxView = UIView()
        yesboxView.backgroundColor = UIColor.systemBlue
        yesboxView.layer.cornerRadius = 10
        yesboxView.layer.masksToBounds = true
        yesboxView.translatesAutoresizingMaskIntoConstraints = false
        whiteView.addSubview(yesboxView)
        
        // 네, 좋아요 박스 위치 크기
        NSLayoutConstraint.activate([
            yesboxView.heightAnchor.constraint(equalToConstant: 55),
            yesboxView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            yesboxView.leadingAnchor.constraint(equalTo: whiteView.leadingAnchor, constant: 24),
            yesboxView.bottomAnchor.constraint(equalTo: nextboxView.topAnchor, constant: -5)
        ])
        
        // "네, 좋아요" 라벨
        let yesLabel = UILabel()
        yesLabel.text = "네, 좋아요"
        yesLabel.textColor = .white
        yesLabel.font = UIFont.systemFont(ofSize: 20, weight: .semibold)
        yesLabel.translatesAutoresizingMaskIntoConstraints = false
        yesboxView.addSubview(yesLabel)
        
        NSLayoutConstraint.activate([
            yesLabel.centerXAnchor.constraint(equalTo: yesboxView.centerXAnchor),
            yesLabel.centerYAnchor.constraint(equalTo: yesboxView.centerYAnchor),
        ])
    }
}

#if DEBUG

import SwiftUI

struct ThirdViewControllerPresentable: UIViewControllerRepresentable {
    func updateUIViewController(_ uiViewController: UIViewControllerType, context: Context) {
    }
    
    func makeUIViewController(context: Context) -> some UIViewController {
        ThirdViewController()
    }
}

struct ThirdViewControllerPresentable_PreviewProvider: PreviewProvider {
    static var previews: some View {
        ThirdViewControllerPresentable()
            .ignoresSafeArea()
    }
}

#endif

